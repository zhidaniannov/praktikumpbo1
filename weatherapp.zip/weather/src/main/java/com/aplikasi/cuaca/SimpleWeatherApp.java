package com.aplikasi.cuaca;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.*;
import java.util.List;
import javax.swing.Timer; 

// Import komponen UI & Ikon
import com.aplikasi.cuaca.UIComponents.*;
import com.aplikasi.cuaca.Icons.*;

public class SimpleWeatherApp {

    // --- STATE ---
    // private static List<Map<String, String>> weatherList = new ArrayList<>(); // TIDAK DIPERLUKAN LAGI UTK PENCARIAN UTAMA
    private static List<String> searchHistory = new ArrayList<>(); 
    private static boolean isCelsius = true; 
    private static String currentCity = "Jakarta"; // Default city
    
    // --- ANIMATION STATE ---
    private static float currentAlpha = 1.0f;
    private static Timer animTimer;

    // --- UI COLORS ---
    public static Color bgTopColor = new Color(74, 144, 226);
    public static Color bgBottomColor = new Color(0, 82, 212);
    private static final Color ACCENT_COLOR = new Color(52, 152, 219); 
    
    // --- UI COMPONENTS ---
    private static JPanel mainPanel;
    private static JPanel bodyPanel;
    private static JLabel lblJam;
    private static JLabel lblTanggal;
    private static ChartPanel chartPanel;
    private static JFrame frame;
    private static RoundedTextField searchField;
    private static JPopupMenu suggestionPopup;
    
    private static final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, dd MMMM yyyy", new Locale("id", "ID"));

    // Komponen UI Global untuk akses update
    private static JLabel lblCityName, lblSuhu, lblCuaca, lblDesc, lblRekomen, lblHumid, lblIcon;
    private static JLabel f1Day, f1Icon, f1Temp, f2Day, f2Icon, f2Temp;

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
        showSplashScreen();
    }

    private static void showSplashScreen() {
        JWindow splash = new JWindow();
        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(new Color(74, 144, 226));
        content.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));

        JLabel title = new JLabel("Weather App Realtime", SwingConstants.CENTER); // Update Judul
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setForeground(Color.WHITE);
        title.setBorder(new EmptyBorder(30, 20, 10, 20));

        JLabel subTitle = new JLabel("Menghubungkan ke Server...", SwingConstants.CENTER);
        subTitle.setForeground(new Color(230, 230, 230));

        JProgressBar progress = new JProgressBar();
        progress.setIndeterminate(true);
        progress.setBorder(new EmptyBorder(0, 60, 40, 60));
        progress.setBackground(new Color(74, 144, 226));
        progress.setForeground(Color.WHITE);

        content.add(title, BorderLayout.NORTH);
        content.add(subTitle, BorderLayout.CENTER);
        content.add(progress, BorderLayout.SOUTH);

        splash.setContentPane(content);
        splash.setSize(500, 300);
        splash.setLocationRelativeTo(null);
        splash.setVisible(true);

        new Thread(() -> {
            try {
                Thread.sleep(1500); // Simulasi loading sebentar
                SwingUtilities.invokeLater(() -> {
                    splash.dispose();
                    createAndShowGUI();
                });
            } catch (Exception e) { e.printStackTrace(); }
        }).start();
    }

    private static void createAndShowGUI() {
        frame = new JFrame("Info Cuaca Realtime");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH); 
        
        mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                GradientPaint gp = new GradientPaint(0, 0, bgTopColor, 0, getHeight(), bgBottomColor);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(new BorderLayout());

        // --- TOP BAR ---
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.setBorder(new EmptyBorder(30, 40, 10, 40));

        JPanel searchContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        searchContainer.setOpaque(false);

        searchField = new RoundedTextField(25);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        searchField.setText("Cari kota...");
        searchField.setForeground(Color.WHITE);
        searchField.setCaretColor(Color.WHITE);
        searchField.setPreferredSize(new Dimension(320, 50)); 

        searchField.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (searchField.getText().equals("Cari kota...")) searchField.setText("");
            }
            public void focusLost(FocusEvent e) {
                if (searchField.getText().isEmpty()) searchField.setText("Cari kota...");
            }
        });

        // suggestionPopup = new JPopupMenu(); // Disable autocomplete lokal sementara
        // setupAutoComplete(searchField);

        ModernButton btnSearch = new ModernButton(new Icons.SearchIcon(22, Color.WHITE), new Color(255, 255, 255, 40), new Color(255,255,255,80));
        btnSearch.setToolTipText("Cari");

        ModernButton btnSettings = new ModernButton(new Icons.SettingsIcon(24, Color.WHITE), new Color(255, 255, 255, 0), new Color(255,255,255,40));
        btnSettings.setToolTipText("Pengaturan");

        searchContainer.add(searchField);
        searchContainer.add(btnSearch);
        searchContainer.add(btnSettings);

        // Panel Kanan (Jam & Tanggal)
        JPanel timePanel = new JPanel(new GridLayout(2, 1));
        timePanel.setOpaque(false);

        lblJam = new JLabel(timeFormat.format(new Date()));
        lblJam.setForeground(Color.WHITE);
        lblJam.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblJam.setHorizontalAlignment(SwingConstants.RIGHT);
        
        lblTanggal = new JLabel(dateFormat.format(new Date()));
        lblTanggal.setForeground(new Color(230, 230, 230));
        lblTanggal.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblTanggal.setHorizontalAlignment(SwingConstants.RIGHT);

        timePanel.add(lblJam);
        timePanel.add(lblTanggal);

        Timer timer = new Timer(1000, e -> {
            Date now = new Date();
            lblJam.setText(timeFormat.format(now));
            lblTanggal.setText(dateFormat.format(now));
        });
        timer.start();

        topPanel.add(searchContainer, BorderLayout.WEST);
        topPanel.add(timePanel, BorderLayout.EAST);

        // --- BODY PANEL ---
        bodyPanel = new JPanel(new BorderLayout()) {
            @Override
            public void paint(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, currentAlpha));
                super.paint(g2);
                g2.dispose();
            }
        };
        bodyPanel.setOpaque(false);

        // --- CENTER INFO ---
        JPanel centerContainer = new JPanel(new GridBagLayout());
        centerContainer.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(5, 0, 5, 0);

        lblCityName = WeatherUtils.createShadowLabel(currentCity, new Font("Segoe UI", Font.BOLD, 46));
        
        lblIcon = new JLabel("☁️");
        lblIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 160));
        lblIcon.setForeground(Color.WHITE);
        lblIcon.setBorder(new EmptyBorder(20, 0, 10, 0));

        lblSuhu = WeatherUtils.createShadowLabel("--°C", new Font("Segoe UI", Font.BOLD, 90));
        lblCuaca = WeatherUtils.createShadowLabel("--", new Font("Segoe UI", Font.BOLD, 32));

        lblDesc = new JLabel("--");
        lblDesc.setFont(new Font("Segoe UI", Font.ITALIC, 18));
        lblDesc.setForeground(new Color(240, 240, 240));
        
        JPanel detailsPanel = new GlassPanel(20);
        detailsPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        detailsPanel.setPreferredSize(new Dimension(300, 50));
        lblHumid = new JLabel("💧 -%");
        lblHumid.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblHumid.setForeground(Color.WHITE);
        JLabel lblWind = new JLabel("🌬️ - km/h"); 
        lblWind.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblWind.setForeground(Color.WHITE);
        detailsPanel.add(lblHumid);
        detailsPanel.add(new JSeparator(JSeparator.VERTICAL));
        detailsPanel.add(lblWind);

        lblRekomen = new JLabel("<html><center>-</center></html>");
        lblRekomen.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblRekomen.setForeground(new Color(255, 255, 255, 220)); 
        lblRekomen.setPreferredSize(new Dimension(700, 45));
        lblRekomen.setHorizontalAlignment(SwingConstants.CENTER);

        centerContainer.add(lblCityName, gbc);
        centerContainer.add(lblIcon, gbc);
        centerContainer.add(lblSuhu, gbc);
        centerContainer.add(lblCuaca, gbc);
        gbc.insets = new Insets(15, 0, 15, 0); 
        centerContainer.add(detailsPanel, gbc);
        gbc.insets = new Insets(5, 0, 5, 0);
        centerContainer.add(lblDesc, gbc);
        centerContainer.add(lblRekomen, gbc);

        // --- BOTTOM ---
        JPanel bottomContainer = new JPanel();
        bottomContainer.setLayout(new BoxLayout(bottomContainer, BoxLayout.Y_AXIS));
        bottomContainer.setOpaque(false);
        bottomContainer.setBorder(new EmptyBorder(10, 60, 50, 60));

        JLabel lblChartTitle = new JLabel("Perkembangan Suhu (Hari Ini - Dummy)");
        lblChartTitle.setForeground(new Color(255, 255, 255, 200));
        lblChartTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblChartTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        chartPanel = new ChartPanel();
        chartPanel.setPreferredSize(new Dimension(800, 180));
        chartPanel.setMaximumSize(new Dimension(1100, 180));
        chartPanel.setOpaque(false);
        chartPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel forecastPanel = new JPanel(new GridLayout(1, 2, 40, 0));
        forecastPanel.setOpaque(false);
        forecastPanel.setMaximumSize(new Dimension(900, 140));

        f1Day = new JLabel("Besok"); f1Icon = new JLabel("☁️"); f1Temp = new JLabel("-");
        JPanel card1 = createForecastCard(f1Day, f1Icon, f1Temp);
        f2Day = new JLabel("Lusa"); f2Icon = new JLabel("☁️"); f2Temp = new JLabel("-");
        JPanel card2 = createForecastCard(f2Day, f2Icon, f2Temp);

        forecastPanel.add(card1);
        forecastPanel.add(card2);

        bottomContainer.add(lblChartTitle);
        bottomContainer.add(Box.createRigidArea(new Dimension(0, 15)));
        bottomContainer.add(chartPanel);
        bottomContainer.add(Box.createRigidArea(new Dimension(0, 35)));
        bottomContainer.add(forecastPanel);

        bodyPanel.add(centerContainer, BorderLayout.CENTER);
        bodyPanel.add(bottomContainer, BorderLayout.SOUTH);

        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(bodyPanel, BorderLayout.CENTER); 
        
        // --- LOGIC: PERUBAHAN KE API REALTIME ---
        
        ActionListener searchAction = e -> {
            suggestionPopup.setVisible(false);
            String q = searchField.getText().trim();
            if (q.equals("Cari kota...") || q.isEmpty()) return;

            // Tampilkan loading cursor
            frame.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            searchField.setEnabled(false);

            // Jalankan Request di Thread berbeda agar UI tidak macet
            new Thread(() -> {
                // Ambil data dari Service
                Map<String, String> data = WeatherAPIService.getWeatherFromAPI(q);
                
                SwingUtilities.invokeLater(() -> {
                    frame.setCursor(Cursor.getDefaultCursor());
                    searchField.setEnabled(true);
                    searchField.setText("");
                    searchField.requestFocus();

                    // Perbaikan: Cek error dari API response
                    if (data != null && !data.containsKey("error")) {
                        currentCity = data.get("kota");
                        updateUIWithData(data);
                        if(!searchHistory.contains(currentCity)) searchHistory.add(currentCity);
                    } else {
                        // Tampilkan pesan error spesifik dari service
                        String errorMsg = (data != null && data.containsKey("error")) 
                                        ? data.get("error") 
                                        : "Koneksi Gagal / Kota Tidak Ditemukan";
                                        
                        JOptionPane.showMessageDialog(frame, 
                            "Gagal mengambil data untuk: " + q + "\n\nPenyebab: " + errorMsg + "\n\nSolusi: Cek API Key atau koneksi internet.", 
                            "Gagal Memuat Data", JOptionPane.ERROR_MESSAGE);
                    }
                });
            }).start();
        };

        btnSearch.addActionListener(searchAction);
        searchField.addActionListener(searchAction);
        btnSettings.addActionListener(e -> showModernSettingsDialog(() -> {
            searchField.setText(currentCity);
            searchAction.actionPerformed(null);
        }));

        // Load Default City saat start
        SwingUtilities.invokeLater(() -> {
            searchField.setText("Jakarta");
            searchAction.actionPerformed(null);
        });
        
        frame.setContentPane(mainPanel);
        frame.setVisible(true);
    }

    // Update UI Helper
    private static void updateUIWithData(Map<String, String> data) {
        lblCityName.setText(data.get("kota"));
        
        // Konversi jika setting Fahrenheit
        String rawSuhu = data.get("suhu"); // Format "30°C"
        lblSuhu.setText(WeatherUtils.formatTemp(rawSuhu, isCelsius)); 
        
        String weatherCond = data.get("cuaca");
        lblCuaca.setText(weatherCond);
        lblDesc.setText(data.get("deskripsi"));
        lblRekomen.setText("<html><center>Rekomendasi: " + data.getOrDefault("rekomendasi", "-") + "</center></html>");
        lblIcon.setText(WeatherUtils.getWeatherEmoji(weatherCond));
        lblHumid.setText("💧 " + data.getOrDefault("kelembaban", "-"));
        
        // Data Forecast Dummy (Keterbatasan API Gratis)
        f1Day.setText(data.getOrDefault("f1_hari", "Besok"));
        f1Temp.setText(WeatherUtils.formatTemp(data.getOrDefault("f1_suhu", "-"), isCelsius));
        f1Icon.setText(WeatherUtils.getWeatherEmoji(data.getOrDefault("f1_cuaca", "")));
        
        f2Day.setText(data.getOrDefault("f2_hari", "Lusa"));
        f2Temp.setText(WeatherUtils.formatTemp(data.getOrDefault("f2_suhu", "-"), isCelsius));
        f2Icon.setText(WeatherUtils.getWeatherEmoji(data.getOrDefault("f2_cuaca", "")));
        
        if (chartPanel != null) chartPanel.setData(data.get("hourly"), isCelsius);
        
        updateThemeColor(weatherCond);
        triggerAnimation();
    }

    // --- ANIMATION LOGIC ---
    private static void triggerAnimation() {
        if (animTimer != null && animTimer.isRunning()) {
            animTimer.stop();
        }
        currentAlpha = 0.0f; 
        bodyPanel.repaint();

        animTimer = new Timer(25, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentAlpha += 0.08f; 
                if (currentAlpha >= 1.0f) {
                    currentAlpha = 1.0f;
                    animTimer.stop();
                }
                bodyPanel.repaint();
            }
        });
        animTimer.start();
    }

    private static JPanel createForecastCard(JLabel day, JLabel icon, JLabel temp) {
        JPanel card = new GlassPanel(25);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        day.setForeground(Color.WHITE); day.setAlignmentX(Component.CENTER_ALIGNMENT);
        day.setFont(new Font("Segoe UI", Font.BOLD, 16));
        icon.setForeground(Color.WHITE); icon.setAlignmentX(Component.CENTER_ALIGNMENT);
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 48));
        temp.setForeground(Color.WHITE); temp.setAlignmentX(Component.CENTER_ALIGNMENT);
        temp.setFont(new Font("Segoe UI", Font.BOLD, 22));
        card.add(day); card.add(Box.createRigidArea(new Dimension(0, 10)));
        card.add(icon); card.add(Box.createRigidArea(new Dimension(0, 10)));
        card.add(temp);
        return card;
    }

    // --- THEME COLOR LOGIC ---
    private static void updateThemeColor(String condition) {
        int hour = LocalTime.now().getHour();
        boolean isNight = (hour >= 18 || hour < 6);
        String c = condition.toLowerCase();
        
        if (isNight) {
            if (c.contains("hujan") || c.contains("petir")) {
                bgTopColor = new Color(44, 62, 80);    
                bgBottomColor = new Color(0, 0, 0); 
            } else if (c.contains("cerah")) {
                bgTopColor = new Color(20, 30, 48);    
                bgBottomColor = new Color(36, 59, 85);
            } else {
                bgTopColor = new Color(15, 32, 39);    
                bgBottomColor = new Color(32, 58, 67);
            }
        } else {
            if (c.contains("petir") || c.contains("badai")) {
                bgTopColor = new Color(72, 85, 99); 
                bgBottomColor = new Color(41, 50, 60); 
            } else if (c.contains("hujan")) {
                bgTopColor = new Color(66, 99, 132);   
                bgBottomColor = new Color(30, 50, 70); 
            } else if (c.contains("cerah") && !c.contains("berawan")) {
                bgTopColor = new Color(86, 204, 242);  
                bgBottomColor = new Color(47, 128, 237); 
            } else if (c.contains("berawan") || c.contains("mendung")) {
                bgTopColor = new Color(168, 192, 255); 
                bgBottomColor = new Color(63, 43, 150); 
            } else if (c.contains("sejuk")) {
                bgTopColor = new Color(17, 153, 142);  
                bgBottomColor = new Color(56, 239, 125); 
            } else {
                bgTopColor = new Color(74, 144, 226); 
                bgBottomColor = new Color(0, 82, 212);
            }
        }
        if (mainPanel != null) mainPanel.repaint();
    }

    private static void showModernSettingsDialog(Runnable updateCallback) {
        JPanel glass = new JPanel() {
            protected void paintComponent(Graphics g) {
                g.setColor(new Color(0, 0, 0, 100));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        glass.setOpaque(false);
        frame.setGlassPane(glass);
        glass.setVisible(true);

        JDialog dialog = new JDialog(frame, "Pengaturan", true);
        dialog.setSize(450, 320);
        dialog.setLocationRelativeTo(frame);
        dialog.setUndecorated(true);
        dialog.setLayout(new BorderLayout());
        
        dialog.addWindowListener(new WindowAdapter() {
            public void windowClosed(WindowEvent e) { glass.setVisible(false); }
        });

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220), 1));
        
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(new EmptyBorder(25, 30, 10, 30));
        JLabel lblTitle = new JLabel("Preferensi");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(new Color(40, 40, 40));
        header.add(lblTitle, BorderLayout.WEST);
        
        JButton btnClose = new JButton("×");
        btnClose.setFont(new Font("Arial", Font.PLAIN, 28));
        btnClose.setForeground(new Color(150, 150, 150));
        btnClose.setBorderPainted(false); btnClose.setContentAreaFilled(false);
        btnClose.setFocusPainted(false); btnClose.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnClose.addActionListener(ev -> dialog.dispose());
        header.add(btnClose, BorderLayout.EAST);

        JPanel body = new JPanel(new GridLayout(1, 2, 20, 0));
        body.setBackground(Color.WHITE);
        body.setBorder(new EmptyBorder(10, 30, 30, 30));

        ButtonGroup bg = new ButtonGroup();
        JToggleButton cardC = createSelectionCard("Celcius", "°C", isCelsius);
        JToggleButton cardF = createSelectionCard("Fahrenheit", "°F", !isCelsius);
        
        bg.add(cardC); bg.add(cardF);
        body.add(cardC); body.add(cardF);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footer.setBackground(Color.WHITE);
        footer.setBorder(new EmptyBorder(0, 30, 25, 30));
        
        JButton btnSave = new JButton("Simpan") {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground()); g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
                super.paintComponent(g2); g2.dispose();
            }
        };
        btnSave.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSave.setForeground(Color.WHITE); btnSave.setBackground(ACCENT_COLOR); 
        btnSave.setPreferredSize(new Dimension(120, 45));
        btnSave.setBorderPainted(false); btnSave.setContentAreaFilled(false);
        btnSave.setFocusPainted(false); btnSave.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSave.addActionListener(ev -> {
            isCelsius = cardC.isSelected();
            updateCallback.run();
            dialog.dispose();
        });
        
        footer.add(btnSave);

        contentPanel.add(header, BorderLayout.NORTH);
        contentPanel.add(body, BorderLayout.CENTER);
        contentPanel.add(footer, BorderLayout.SOUTH);
        dialog.add(contentPanel);
        dialog.setVisible(true);
    }

    private static JToggleButton createSelectionCard(String title, String symbol, boolean selected) {
        JToggleButton btn = new JToggleButton() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                if (isSelected()) {
                    g2.setColor(new Color(235, 245, 255));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                    g2.setColor(ACCENT_COLOR);
                    g2.setStroke(new BasicStroke(2));
                    g2.drawRoundRect(1, 1, getWidth()-2, getHeight()-2, 20, 20);
                } else {
                    g2.setColor(new Color(250, 250, 250));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                    g2.setColor(new Color(220, 220, 220));
                    g2.setStroke(new BasicStroke(1));
                    g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                }
                
                g2.setFont(new Font("Segoe UI", Font.BOLD, 48));
                g2.setColor(isSelected() ? ACCENT_COLOR : Color.GRAY);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(symbol, (getWidth() - fm.stringWidth(symbol))/2, getHeight()/2 + 10);
                
                g2.setFont(new Font("Segoe UI", Font.BOLD, 14));
                fm = g2.getFontMetrics();
                g2.drawString(title, (getWidth() - fm.stringWidth(title))/2, getHeight() - 20);
                
                if(isSelected()) {
                    Icon check = new Icons.CheckIcon(20, ACCENT_COLOR);
                    check.paintIcon(this, g2, getWidth() - 30, 10);
                }
                
                g2.dispose();
            }
        };
        btn.setSelected(selected);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
}